#!/usr/bin/env python3
"""Paper figures, styled to match the printed AIMS poster (Poster/scripts/plots.gp).

Inputs (copied from the runs' portable evidence; no inferred values):
  data/history.csv          VeRL/MATH run: step, proxy (recorded), reference (rescored)
  data/recovery.csv         recovery arms: incident, start checkpoint, relative_step, reference
  data/toy_subgroup.json    controlled partial regression, final 50 updates
Usage: python figures/make_figures.py
  writes figures/verl_incident.pdf (Figure 2) and figures/subgroup.pdf (Figure 3)
"""
import csv
import json
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
plt.rcParams.update({
    "text.usetex": True,
    "text.latex.preamble": r"\usepackage{mathpazo}",
    "font.family": "serif",
    "font.size": 8.5,
    "axes.spines.top": False,
    "axes.spines.right": False,
})
# Poster palette.
BLUE, ORANGE, GREEN, INK = "#225A81", "#D55E00", "#418774", "#183047"
REF_LABEL = r"pinned-reference accuracy (\%)"


def rows(name):
    with (HERE / "data" / name).open() as f:
        return list(csv.DictReader(f))


def verl_incident():
    hist = rows("history.csv")
    rec = [r for r in rows("recovery.csv") if r["incident"] == "loom_incident_base"]

    fig, (a, b) = plt.subplots(1, 2, figsize=(5.5, 1.85), layout="constrained",
                               gridspec_kw={"width_ratios": [1.35, 1]})

    t = [int(r["step"]) for r in hist]
    a.axvspan(60.5, 130.5, color="0.93", lw=0)
    a.plot(t, [100 * float(r["proxy"]) for r in hist], c=ORANGE, lw=1.1, label="recorded")
    a.plot(t, [100 * float(r["reference"]) for r in hist], c=BLUE, lw=1.1,
           label="pinned reference")
    a.axvline(60.5, ls="--", c="0.35", lw=0.8)
    a.annotate("first disagreement:\nupdate 61", xy=(60.5, 10), xytext=(6, 10),
               fontsize=7, va="center", arrowprops=dict(arrowstyle="->", lw=0.6, color="0.3"))
    a.set(xlabel="training update", ylabel=r"pass rate (\%)", xlim=(0, 131), ylim=(-3, 104),
          yticks=[0, 25, 50, 75, 100], title="(a) training batches")
    a.legend(loc="upper left", fontsize=6.8, frameon=False)

    for start, col, ls, lab in [(60, BLUE, "-", "Checkpoint 60"),
                                (130, ORANGE, "-", "Checkpoint 130"),
                                (80, GREEN, "--", "Checkpoint 80*")]:
        rr = [r for r in rec if int(r["start"]) == start]
        b.plot([int(r["relative_step"]) for r in rr],
               [100 * float(r["reference"]) for r in rr], c=col, ls=ls, lw=1.1, label=lab)
    b.set(xlabel="fresh recovery updates", ylabel=REF_LABEL, xlim=(0, 41), ylim=(-3, 104),
          yticks=[0, 25, 50, 75, 100], title="(b) recovery, repaired verifier")
    b.legend(loc="center right", bbox_to_anchor=(1.0, 0.27), fontsize=6.8, frameon=False)

    for ax in (a, b):
        ax.grid(alpha=0.18)
        ax.title.set_fontsize(8.5)
    fig.savefig(HERE / "verl_incident.pdf")
    plt.close(fig)


def pct(v):
    # Round half up, as on the poster (43.05 -> 43.1).
    d = Decimal(repr(round(v, 6))).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP)
    return rf"{d}\%"


def subgroup():
    s = json.loads((HERE / "data" / "toy_subgroup.json").read_text())
    bars = [("Overall", 100 * s["final50_avg_hidden"], BLUE),
            ("Affected slice", 100 * s["final50_hidden_affected"], ORANGE),
            ("Other prompts", 100 * s["final50_hidden_unaffected"], BLUE)]
    fig, ax = plt.subplots(figsize=(3.4, 1.15), layout="constrained")
    y = range(len(bars))[::-1]
    ax.barh(list(y), [v for _, v, _ in bars], color=[c for _, _, c in bars], height=0.5)
    for yi, (_, v, _) in zip(y, bars):
        ax.text(v + 1.5, yi, pct(v), va="center", fontsize=7.5, color=INK)
    ax.set_yticks(list(y), [n for n, _, _ in bars])
    ax.tick_params(axis="y", length=0)
    ax.spines["left"].set_visible(False)
    ax.set(xlim=(0, 100), xticks=[0, 25, 50, 75, 100], xlabel=REF_LABEL)
    ax.grid(axis="x", alpha=0.18)
    fig.savefig(HERE / "subgroup.pdf")
    plt.close(fig)


if __name__ == "__main__":
    verl_incident()
    subgroup()
